<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Admin_produkController extends Controller
{
    //
}
